// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get appTitle => 'موظفو وافلو';

  @override
  String get bootProgress => 'جارٍ التحقق من هذا الجهاز بأمان';

  @override
  String get welcomeTitle => 'إقران جهاز الموظف';

  @override
  String get welcomeBody =>
      'اطلب من المالك أو المدير إنشاء رمز إقران لمرة واحدة من لوحة تحكم وافلو.';

  @override
  String get scanPairingCode => 'مسح رمز الإقران';

  @override
  String get securitySummary =>
      'لن تُدخل كلمة مرور لوحة التحكم هنا. ينشئ هذا الجهاز مفتاح الحماية الخاص به ويحميه.';

  @override
  String get chooseLanguage => 'اللغة';

  @override
  String get english => 'English';

  @override
  String get arabic => 'العربية';

  @override
  String get cameraTitle => 'استخدام الكاميرا للإقران';

  @override
  String get cameraBody =>
      'تستخدم وافلو للموظفين الكاميرا فقط لمسح رمز إقران جهاز الموظف لمرة واحدة.';

  @override
  String get continueAction => 'متابعة';

  @override
  String get notNow => 'ليس الآن';

  @override
  String get openSettings => 'فتح الإعدادات';

  @override
  String get cameraDenied =>
      'الوصول إلى الكاميرا متوقف. يمكنك إدخال رمز الإقران بأمان بدلاً من ذلك.';

  @override
  String get scannerTitle => 'مسح رمز إقران الموظف';

  @override
  String get scannerInstructions =>
      'ضع رمز إقران الموظف لمرة واحدة داخل الإطار.';

  @override
  String get toggleFlash => 'تشغيل أو إيقاف ضوء الكاميرا';

  @override
  String get close => 'إغلاق';

  @override
  String get enterCodeInstead => 'إدخال الرمز بدلاً من ذلك';

  @override
  String get manualCodeTitle => 'إدخال رمز الإقران';

  @override
  String get manualCodeHint => 'رمز الإقران لمرة واحدة';

  @override
  String get submitCode => 'متابعة بأمان';

  @override
  String get invalidPairing => 'هذا ليس رمز إقران صالحاً لموظفي وافلو.';

  @override
  String get expiredPairing => 'انتهت صلاحية رمز الإقران. اطلب رمزاً جديداً.';

  @override
  String get usedPairing => 'استُخدم رمز الإقران مسبقاً. اطلب رمزاً جديداً.';

  @override
  String get wrongEnvironmentPairing =>
      'رمز الإقران هذا تابع لبيئة وافلو أخرى.';

  @override
  String get pairingProgressTitle => 'جارٍ تأمين الجهاز';

  @override
  String get pairingValidating => 'جارٍ التحقق من رمز الإقران';

  @override
  String get pairingCreatingIdentity => 'جارٍ إنشاء مفتاح حماية الجهاز';

  @override
  String get pairingClaiming => 'جارٍ حجز جلسة الإقران';

  @override
  String get pairingRecovering => 'جارٍ استعادة تحدي الإقران الآمن';

  @override
  String get pairingSigning => 'جارٍ توقيع تحدي الحماية';

  @override
  String get pairingCompleting => 'جارٍ إكمال إقران الجهاز';

  @override
  String get pairingSaving => 'جارٍ حفظ الجلسة الآمنة';

  @override
  String get pairingLoadingContext => 'جارٍ تحميل سياق الجهاز المعيّن';

  @override
  String get pairingSuccessTitle => 'تم إقران الجهاز';

  @override
  String get pairingSuccessBody =>
      'الجهاز جاهز للاستخدام المصرح به من موظفي وافلو.';

  @override
  String get goHome => 'المتابعة إلى الرئيسية';

  @override
  String get deviceReady => 'الجهاز جاهز';

  @override
  String get verifiedByWaflo => 'تم التحقق بواسطة وافلو';

  @override
  String get roleLabel => 'الدور';

  @override
  String get roleOwner => 'المالك';

  @override
  String get roleManager => 'المدير';

  @override
  String get roleStaff => 'الموظف';

  @override
  String get platformLabel => 'المنصة';

  @override
  String get platformIos => 'iOS';

  @override
  String get platformAndroid => 'Android';

  @override
  String get organizationLabel => 'المؤسسة';

  @override
  String get staffLabel => 'الموظف';

  @override
  String get deviceStatusLabel => 'حالة الجهاز';

  @override
  String get currentLocationLabel => 'الموقع الحالي';

  @override
  String get locationsTitle => 'المواقع المعيّنة';

  @override
  String get earningCapability => 'الاكتساب';

  @override
  String get redemptionCapability => 'الاستبدال';

  @override
  String get capabilityAllowed => 'مسموح';

  @override
  String get capabilityBlocked => 'غير مسموح';

  @override
  String get updatePolicyLabel => 'سياسة التحديث';

  @override
  String minimumSupportedVersion(Object version) {
    return 'الحد الأدنى للإصدار المدعوم: $version';
  }

  @override
  String get appVersionCurrent => 'إصدار التطبيق هذا مدعوم';

  @override
  String assignedLocations(num count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count موقع معيّن',
      many: '$count موقعاً معيّناً',
      few: '$count مواقع معيّنة',
      two: 'موقعان معيّنان',
      one: 'موقع معيّن واحد',
      zero: 'لا توجد مواقع معيّنة',
    );
    return '$_temp0';
  }

  @override
  String get securityStatus => 'حالة الحماية';

  @override
  String get active => 'نشط';

  @override
  String lastSynchronized(Object time) {
    return 'آخر مزامنة $time';
  }

  @override
  String get home => 'الرئيسية';

  @override
  String get settings => 'الإعدادات';

  @override
  String get scanCustomer => 'مسح العميل';

  @override
  String get recentOperations => 'العمليات الأخيرة';

  @override
  String get managerApprovals => 'موافقات المدير';

  @override
  String get availableInNextPhase => 'غير متاح في M1';

  @override
  String get appearance => 'المظهر';

  @override
  String get themeSystem => 'مظهر النظام';

  @override
  String get themeLight => 'فاتح';

  @override
  String get themeDark => 'داكن';

  @override
  String get deviceInformation => 'معلومات الجهاز';

  @override
  String appVersion(Object version) {
    return 'إصدار التطبيق $version';
  }

  @override
  String environment(Object environment) {
    return 'البيئة: $environment';
  }

  @override
  String get refreshContext => 'تحديث سياق الجهاز';

  @override
  String get signOut => 'تسجيل الخروج';

  @override
  String get signOutTitle => 'تسجيل الخروج من هذا الجهاز؟';

  @override
  String get signOutBody =>
      'ستُحذف جلسة الخادم ومفتاح الحماية المحلي، وستحتاج إلى رمز إقران جديد من لوحة التحكم.';

  @override
  String get cancel => 'إلغاء';

  @override
  String get privacy => 'الخصوصية';

  @override
  String get support => 'الدعم';

  @override
  String get openSourceLicenses => 'تراخيص المصادر المفتوحة';

  @override
  String get offlineBanner =>
      'لا يمكن الوصول إلى وافلو. لا تسمح المعلومات المحفوظة بتنفيذ أي عمليات.';

  @override
  String get retry => 'إعادة المحاولة';

  @override
  String get sessionExpiredTitle => 'انتهت صلاحية الجلسة';

  @override
  String get sessionExpiredBody =>
      'يحتاج هذا الجهاز إلى رمز إقران جديد قبل المتابعة.';

  @override
  String get deviceRevokedTitle => 'تم إلغاء الجهاز';

  @override
  String get deviceRevokedBody =>
      'لم يعد هذا الجهاز مصرحاً به. تواصل مع المالك أو المدير.';

  @override
  String get deviceCompromisedTitle => 'تم حظر الجهاز للحماية';

  @override
  String get deviceCompromisedBody =>
      'حظرت وافلو هذا الجهاز لحماية حساب التاجر.';

  @override
  String get updateRequiredTitle => 'التحديث مطلوب';

  @override
  String get updateRequiredBody =>
      'ثبّت أحدث إصدار من وافلو للموظفين للمتابعة بأمان.';

  @override
  String get backendUnavailableTitle => 'وافلو غير متاحة';

  @override
  String get backendUnavailableBody =>
      'تحقق من الاتصال ثم حاول مجدداً. لم يُصنّف جهازك على أنه ملغى.';

  @override
  String get configurationErrorTitle => 'خطأ في إعداد التطبيق';

  @override
  String get configurationErrorBody =>
      'لا يستطيع هذا الإصدار الاتصال بأمان. تواصل مع دعم وافلو.';

  @override
  String get localSecurityErrorTitle => 'مفتاح الحماية المحلي غير متاح';

  @override
  String get localSecurityErrorBody =>
      'مفتاح الجهاز المقترن مفقود أو تالف. يلزم إعادة ضبط مقصودة وإقران جديد.';

  @override
  String get resetForRepair => 'إعادة الضبط لإقران جديد';

  @override
  String get genericError => 'حدث خطأ. حاول مرة أخرى بأمان.';

  @override
  String get validationError => 'تحقق من معلومات الإقران المرسلة.';

  @override
  String get signatureError => 'تعذر التحقق من طلب الجهاز الآمن.';

  @override
  String get clockSkewError => 'فعّل التاريخ والوقت التلقائيين ثم حاول مجدداً.';

  @override
  String get nonceReplayError =>
      'استُخدم الطلب مسبقاً. يلزم إنشاء طلب آمن جديد.';

  @override
  String get assignmentRequiredError => 'يلزم تعيين موظف نشط لهذا الجهاز.';

  @override
  String get locationNotAuthorizedError =>
      'هذا الجهاز غير مصرح له بهذا الموقع.';

  @override
  String get riskBlockedError => 'حظرت وافلو هذا الطلب لمراجعة الحماية.';

  @override
  String requestReference(Object requestId) {
    return 'مرجع الطلب: $requestId';
  }

  @override
  String get m2ScannerTitle => 'مسح عضوية العميل';

  @override
  String get m2ScannerInstructions =>
      'ضع رمز عضوية وافلو للعميل داخل الإطار. لن يُعرض الرمز أو يُحفظ.';

  @override
  String get resolvingMembership => 'جارٍ التحقق من العضوية بأمان';

  @override
  String get membershipTitle => 'العضوية';

  @override
  String get customerLabel => 'العميل';

  @override
  String get programLabel => 'البرنامج';

  @override
  String get membershipStatusLabel => 'حالة العضوية';

  @override
  String get membershipStatusActive => 'نشطة';

  @override
  String get membershipStatusSuspended => 'معلّقة';

  @override
  String get membershipStatusExpired => 'منتهية';

  @override
  String get membershipStatusRevoked => 'ملغاة';

  @override
  String progressOf(Object goal, Object progress) {
    return '$progress من $goal طوابع';
  }

  @override
  String completedCycles(Object count) {
    return 'الدورات المكتملة: $count';
  }

  @override
  String resolvedAt(Object time) {
    return 'تم التحقق $time';
  }

  @override
  String get rewardReady => 'المكافأة النهائية جاهزة';

  @override
  String get earningAvailable => 'إضافة الطوابع متاحة هنا';

  @override
  String get redemptionAvailable => 'استرداد المكافآت متاح هنا';

  @override
  String get stampAmount => 'عدد الطوابع';

  @override
  String projectedProgress(Object goal, Object progress) {
    return 'بعد الموافقة: $progress من $goal';
  }

  @override
  String get purchaseAmount => 'مبلغ الشراء';

  @override
  String requiredCurrency(Object currency) {
    return 'العملة المطلوبة: $currency';
  }

  @override
  String purchaseMinimum(Object amount) {
    return 'الحد الأدنى للشراء: $amount';
  }

  @override
  String get transactionReference => 'مرجع المعاملة';

  @override
  String get optionalLabel => 'اختياري';

  @override
  String get continueToReview => 'مراجعة العملية';

  @override
  String get reviewStampTitle => 'مراجعة إصدار الطوابع';

  @override
  String get confirmStamp => 'تأكيد إصدار الطوابع';

  @override
  String get issuingStamps => 'جارٍ إصدار الطوابع بأمان';

  @override
  String get stampSuccessTitle => 'تم إصدار الطوابع';

  @override
  String stampsIssued(num count) {
    return 'تم إصدار $count طابع';
  }

  @override
  String get rewardUnlocked => 'تم فتح مكافأة';

  @override
  String get scanNextCustomer => 'مسح العميل التالي';

  @override
  String get rewardsTitle => 'المكافآت المتاحة';

  @override
  String get milestoneReward => 'مكافأة مرحلية';

  @override
  String get finalReward => 'المكافأة النهائية';

  @override
  String thresholdLabel(Object count) {
    return 'الحد: $count طوابع';
  }

  @override
  String expirationLabel(Object date) {
    return 'تنتهي في $date';
  }

  @override
  String redemptionCount(Object count, Object maximum) {
    return 'استُردت $count من $maximum';
  }

  @override
  String get managerApprovalRequired => 'موافقة المدير مطلوبة';

  @override
  String get managerApprovalBody =>
      'لا يمكن استرداد هذه المكافأة في M2. استخدم مسار مدير معتمداً عند توفره.';

  @override
  String get redeem => 'استرداد المكافأة';

  @override
  String get redemptionReviewTitle => 'مراجعة استرداد المكافأة';

  @override
  String finalResetWarning(Object goal) {
    return 'بعد الاسترداد ستكتمل هذه الدورة وتعود بطاقة الطوابع إلى 0 من $goal.';
  }

  @override
  String get confirmRedemption => 'تأكيد الاسترداد';

  @override
  String get redeemingReward => 'جارٍ استرداد المكافأة بأمان';

  @override
  String get redemptionSuccessTitle => 'تم استرداد المكافأة';

  @override
  String get progressUnchanged => 'تقدم الطوابع لم يتغير.';

  @override
  String cycleResetComplete(Object goal) {
    return 'اكتملت الدورة وعاد التقدم إلى 0 من $goal.';
  }

  @override
  String get pendingOperationTitle => 'نتيجة العملية قيد الانتظار';

  @override
  String get pendingOperationBody =>
      'لا تبدأ عملية جديدة. تحقق من نتيجة الأمر الأصلي عند توفر الاتصال.';

  @override
  String get checkStatus => 'التحقق من النتيجة';

  @override
  String get dismissRecovery => 'العودة للرئيسية';

  @override
  String get rescanRequired =>
      'امسح عضوية العميل مجدداً قبل إعادة محاولة الأمر نفسه.';

  @override
  String get offlineOperationsBlocked =>
      'تتطلب عمليات الولاء اتصالاً بالإنترنت.';

  @override
  String get noCapabilitiesBody =>
      'هذا الموقع لا يسمح بإضافة الطوابع أو الاسترداد. حدّث سياق الجهاز أو تواصل مع مدير.';

  @override
  String get notAvailableInM2 => 'غير متاح في M2';

  @override
  String get refreshRequired => 'تحديث السياق';

  @override
  String operationReferenceSuffix(Object suffix) {
    return 'مرجع العملية ينتهي بـ $suffix';
  }

  @override
  String get done => 'تم';

  @override
  String get finalReady =>
      'جميع الطوابع ممتلئة. استرد المكافأة النهائية قبل إضافة طوابع أخرى.';

  @override
  String get m2CredentialInvalid =>
      'رمز العضوية غير صالح. اطلب من العميل إظهار رمز جديد.';

  @override
  String get m2MembershipBlocked =>
      'هذه العضوية أو البرنامج غير متاح لعمليات الولاء.';

  @override
  String get m2ProgramMismatch => 'تغيّر البرنامج. امسح العضوية مجدداً.';

  @override
  String get m2LocationBlocked => 'هذه العملية غير مصرح بها في الموقع الحالي.';

  @override
  String get m2StampPolicyBlocked => 'عدد الطوابع المحدد غير مسموح.';

  @override
  String get m2DailyLimit => 'تم بلوغ الحد اليومي للطوابع.';

  @override
  String get m2PurchaseRequired => 'أدخل مبلغ الشراء المطلوب.';

  @override
  String get m2CurrencyMismatch =>
      'استخدم العملة الدقيقة المطلوبة من البرنامج.';

  @override
  String get m2PurchaseThreshold => 'مبلغ الشراء أقل من الحد المطلوب.';

  @override
  String get m2FinalPending =>
      'استرد المكافأة النهائية قبل إصدار طوابع إضافية.';

  @override
  String get m2RewardUnavailable => 'هذه المكافأة لم تعد متاحة.';

  @override
  String get m2RewardExpired => 'انتهت صلاحية هذه المكافأة.';

  @override
  String get m2RewardRedeemed => 'تم استرداد هذه المكافأة مسبقاً.';

  @override
  String get m2ManagerApproval => 'يلزم مسار مدير معتمد، ولن يتجاوزه التطبيق.';

  @override
  String get m2IdempotencyConflict =>
      'تفاصيل العملية الأصلية لا تطابق هذا الأمر. تواصل مع الدعم.';

  @override
  String get m2OperationNotFound => 'لم يتم العثور على الأمر الأصلي.';

  @override
  String get m2OperationProcessing => 'العملية الأصلية ما زالت قيد المعالجة.';

  @override
  String get m2OperationFailed => 'فشلت العملية الأصلية ولم يُسجل نجاح.';

  @override
  String get m2BillingBlocked => 'عمليات الولاء غير متاحة لهذه المؤسسة.';

  @override
  String get m2RiskBlocked => 'حظرت وافلو العملية للمراجعة الأمنية.';

  @override
  String get m2RateLimited => 'طلبات كثيرة جداً. انتظر قليلاً ثم تحقق مجدداً.';

  @override
  String get m2ContractError =>
      'أعادت وافلو استجابة غير آمنة أو غير متوافقة، لذا عُطلت العمليات.';

  @override
  String get m2RecoveryExpired =>
      'تحتاج هذه النتيجة المعلقة إلى دعم وافلو قبل محاولة عملية أخرى.';

  @override
  String get m2ResultUnknown =>
      'نتيجة الخادم غير معروفة. لا تكرر العملية، بل تحقق من حالتها.';
}
