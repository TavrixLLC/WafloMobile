// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appTitle => 'Waflo Staff';

  @override
  String get bootProgress => 'Checking this device securely';

  @override
  String get welcomeTitle => 'Pair this staff device';

  @override
  String get welcomeBody =>
      'Ask an Owner or Manager to create a one-time staff pairing code in the Waflo dashboard.';

  @override
  String get scanPairingCode => 'Scan pairing code';

  @override
  String get securitySummary =>
      'No dashboard password is entered here. This device creates and protects its own security key.';

  @override
  String get chooseLanguage => 'Language';

  @override
  String get english => 'English';

  @override
  String get arabic => 'العربية';

  @override
  String get cameraTitle => 'Camera access for pairing';

  @override
  String get cameraBody =>
      'Waflo Staff uses the camera only to scan a one-time staff device pairing code.';

  @override
  String get continueAction => 'Continue';

  @override
  String get notNow => 'Not now';

  @override
  String get openSettings => 'Open settings';

  @override
  String get cameraDenied =>
      'Camera access is off. You can enter the pairing code securely instead.';

  @override
  String get scannerTitle => 'Scan staff pairing code';

  @override
  String get scannerInstructions =>
      'Place the one-time staff pairing code inside the frame.';

  @override
  String get toggleFlash => 'Toggle camera flash';

  @override
  String get close => 'Close';

  @override
  String get enterCodeInstead => 'Enter code instead';

  @override
  String get manualCodeTitle => 'Enter pairing code';

  @override
  String get manualCodeHint => 'One-time pairing code';

  @override
  String get submitCode => 'Continue securely';

  @override
  String get invalidPairing => 'This is not a valid Waflo staff pairing code.';

  @override
  String get expiredPairing =>
      'This pairing code has expired. Ask for a new code.';

  @override
  String get usedPairing =>
      'This pairing code was already used. Ask for a new code.';

  @override
  String get wrongEnvironmentPairing =>
      'This pairing code belongs to another Waflo environment.';

  @override
  String get pairingProgressTitle => 'Securing this device';

  @override
  String get pairingValidating => 'Validating the pairing code';

  @override
  String get pairingCreatingIdentity => 'Creating the device security key';

  @override
  String get pairingClaiming => 'Claiming the pairing session';

  @override
  String get pairingRecovering => 'Recovering the secure pairing challenge';

  @override
  String get pairingSigning => 'Signing the secure challenge';

  @override
  String get pairingCompleting => 'Completing device pairing';

  @override
  String get pairingSaving => 'Saving the secure session';

  @override
  String get pairingLoadingContext => 'Loading the assigned device context';

  @override
  String get pairingSuccessTitle => 'Device paired';

  @override
  String get pairingSuccessBody =>
      'This device is ready for authorized Waflo staff use.';

  @override
  String get goHome => 'Continue to home';

  @override
  String get deviceReady => 'Device ready';

  @override
  String get verifiedByWaflo => 'Verified by Waflo';

  @override
  String get roleLabel => 'Role';

  @override
  String get roleOwner => 'Owner';

  @override
  String get roleManager => 'Manager';

  @override
  String get roleStaff => 'Staff';

  @override
  String get platformLabel => 'Platform';

  @override
  String get platformIos => 'iOS';

  @override
  String get platformAndroid => 'Android';

  @override
  String get organizationLabel => 'Organization';

  @override
  String get staffLabel => 'Staff member';

  @override
  String get deviceStatusLabel => 'Device status';

  @override
  String get currentLocationLabel => 'Current location';

  @override
  String get locationsTitle => 'Assigned locations';

  @override
  String get earningCapability => 'Earning';

  @override
  String get redemptionCapability => 'Redemption';

  @override
  String get capabilityAllowed => 'Allowed';

  @override
  String get capabilityBlocked => 'Not allowed';

  @override
  String get updatePolicyLabel => 'Update policy';

  @override
  String minimumSupportedVersion(Object version) {
    return 'Minimum supported version: $version';
  }

  @override
  String get appVersionCurrent => 'This app version is supported';

  @override
  String assignedLocations(num count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count assigned locations',
      one: '1 assigned location',
      zero: 'No assigned locations',
    );
    return '$_temp0';
  }

  @override
  String get securityStatus => 'Security status';

  @override
  String get active => 'Active';

  @override
  String lastSynchronized(Object time) {
    return 'Last synchronized $time';
  }

  @override
  String get home => 'Home';

  @override
  String get settings => 'Settings';

  @override
  String get scanCustomer => 'Scan customer';

  @override
  String get recentOperations => 'Recent operations';

  @override
  String get managerApprovals => 'Manager approvals';

  @override
  String get availableInNextPhase => 'Not available in M1';

  @override
  String get appearance => 'Appearance';

  @override
  String get themeSystem => 'System theme';

  @override
  String get themeLight => 'Light';

  @override
  String get themeDark => 'Dark';

  @override
  String get deviceInformation => 'Device information';

  @override
  String appVersion(Object version) {
    return 'App version $version';
  }

  @override
  String environment(Object environment) {
    return 'Environment: $environment';
  }

  @override
  String get refreshContext => 'Refresh device context';

  @override
  String get signOut => 'Sign out';

  @override
  String get signOutTitle => 'Sign out of this device?';

  @override
  String get signOutBody =>
      'The server session and local security key will be removed. A new dashboard pairing code will be required.';

  @override
  String get cancel => 'Cancel';

  @override
  String get privacy => 'Privacy';

  @override
  String get support => 'Support';

  @override
  String get openSourceLicenses => 'Open-source licenses';

  @override
  String get offlineBanner =>
      'Waflo is unreachable. Cached information cannot authorize operations.';

  @override
  String get retry => 'Try again';

  @override
  String get sessionExpiredTitle => 'Session expired';

  @override
  String get sessionExpiredBody =>
      'This device needs a new pairing code before it can continue.';

  @override
  String get deviceRevokedTitle => 'Device revoked';

  @override
  String get deviceRevokedBody =>
      'This device is no longer authorized. Contact an Owner or Manager.';

  @override
  String get deviceCompromisedTitle => 'Device blocked for security';

  @override
  String get deviceCompromisedBody =>
      'Waflo blocked this device to protect the merchant account.';

  @override
  String get updateRequiredTitle => 'Update required';

  @override
  String get updateRequiredBody =>
      'Install the latest Waflo Staff version to continue securely.';

  @override
  String get backendUnavailableTitle => 'Waflo is unavailable';

  @override
  String get backendUnavailableBody =>
      'Check your connection and try again. Your device was not marked revoked.';

  @override
  String get configurationErrorTitle => 'App configuration error';

  @override
  String get configurationErrorBody =>
      'This build cannot connect safely. Contact Waflo support.';

  @override
  String get localSecurityErrorTitle => 'Local security key unavailable';

  @override
  String get localSecurityErrorBody =>
      'The paired key is missing or damaged. A deliberate device reset and new pairing are required.';

  @override
  String get resetForRepair => 'Reset for new pairing';

  @override
  String get genericError => 'Something went wrong. Try again safely.';

  @override
  String get validationError => 'Check the submitted pairing information.';

  @override
  String get signatureError =>
      'The secure device request could not be verified.';

  @override
  String get clockSkewError =>
      'Turn on automatic date and time, then try again.';

  @override
  String get nonceReplayError =>
      'The request was already used. A fresh secure request is required.';

  @override
  String get assignmentRequiredError =>
      'An active staff assignment is required for this device.';

  @override
  String get locationNotAuthorizedError =>
      'This device is not authorized for that location.';

  @override
  String get riskBlockedError =>
      'Waflo blocked this request for security review.';

  @override
  String requestReference(Object requestId) {
    return 'Request reference: $requestId';
  }

  @override
  String get m2ScannerTitle => 'Scan customer membership';

  @override
  String get m2ScannerInstructions =>
      'Place the customer Waflo membership QR inside the frame. The code is not displayed or saved.';

  @override
  String get resolvingMembership => 'Resolving membership securely';

  @override
  String get membershipTitle => 'Membership';

  @override
  String get customerLabel => 'Customer';

  @override
  String get programLabel => 'Program';

  @override
  String get membershipStatusLabel => 'Membership status';

  @override
  String get membershipStatusActive => 'Active';

  @override
  String get membershipStatusSuspended => 'Suspended';

  @override
  String get membershipStatusExpired => 'Expired';

  @override
  String get membershipStatusRevoked => 'Revoked';

  @override
  String progressOf(Object goal, Object progress) {
    return '$progress of $goal stamps';
  }

  @override
  String completedCycles(Object count) {
    return 'Completed cycles: $count';
  }

  @override
  String resolvedAt(Object time) {
    return 'Resolved $time';
  }

  @override
  String get rewardReady => 'Final reward ready';

  @override
  String get earningAvailable => 'Earning is available here';

  @override
  String get redemptionAvailable => 'Redemption is available here';

  @override
  String get stampAmount => 'Stamp amount';

  @override
  String projectedProgress(Object goal, Object progress) {
    return 'After approval: $progress of $goal';
  }

  @override
  String get purchaseAmount => 'Purchase amount';

  @override
  String requiredCurrency(Object currency) {
    return 'Required currency: $currency';
  }

  @override
  String purchaseMinimum(Object amount) {
    return 'Minimum purchase: $amount';
  }

  @override
  String get transactionReference => 'Transaction reference';

  @override
  String get optionalLabel => 'Optional';

  @override
  String get continueToReview => 'Review operation';

  @override
  String get reviewStampTitle => 'Review stamp issuance';

  @override
  String get confirmStamp => 'Confirm stamp issuance';

  @override
  String get issuingStamps => 'Issuing stamps securely';

  @override
  String get stampSuccessTitle => 'Stamps issued';

  @override
  String stampsIssued(num count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count stamps issued',
      one: '1 stamp issued',
    );
    return '$_temp0';
  }

  @override
  String get rewardUnlocked => 'Reward unlocked';

  @override
  String get scanNextCustomer => 'Scan next customer';

  @override
  String get rewardsTitle => 'Available rewards';

  @override
  String get milestoneReward => 'Milestone reward';

  @override
  String get finalReward => 'Final reward';

  @override
  String thresholdLabel(Object count) {
    return 'Threshold: $count stamps';
  }

  @override
  String expirationLabel(Object date) {
    return 'Expires $date';
  }

  @override
  String redemptionCount(Object count, Object maximum) {
    return 'Redeemed $count of $maximum';
  }

  @override
  String get managerApprovalRequired => 'Manager approval required';

  @override
  String get managerApprovalBody =>
      'This reward cannot be redeemed in M2. Use an approved Manager flow when it becomes available.';

  @override
  String get redeem => 'Redeem reward';

  @override
  String get redemptionReviewTitle => 'Review reward redemption';

  @override
  String finalResetWarning(Object goal) {
    return 'After redemption, this cycle will complete and the stamp card will reset to 0 of $goal.';
  }

  @override
  String get confirmRedemption => 'Confirm redemption';

  @override
  String get redeemingReward => 'Redeeming reward securely';

  @override
  String get redemptionSuccessTitle => 'Reward redeemed';

  @override
  String get progressUnchanged => 'Stamp progress is unchanged.';

  @override
  String cycleResetComplete(Object goal) {
    return 'Cycle completed. Progress reset to 0 of $goal.';
  }

  @override
  String get pendingOperationTitle => 'Operation result pending';

  @override
  String get pendingOperationBody =>
      'Do not start a new operation. Check the original command result when the connection is available.';

  @override
  String get checkStatus => 'Check result';

  @override
  String get dismissRecovery => 'Return home';

  @override
  String get rescanRequired =>
      'Scan the customer membership again before retrying the same command.';

  @override
  String get offlineOperationsBlocked =>
      'Loyalty operations require an online connection.';

  @override
  String get noCapabilitiesBody =>
      'This location permits neither earning nor redemption. Refresh the device context or contact a Manager.';

  @override
  String get notAvailableInM2 => 'Not available in M2';

  @override
  String get refreshRequired => 'Refresh context';

  @override
  String operationReferenceSuffix(Object suffix) {
    return 'Operation reference ending $suffix';
  }

  @override
  String get done => 'Done';

  @override
  String get finalReady =>
      'All stamps are filled. Redeem the final reward before earning more.';

  @override
  String get m2CredentialInvalid =>
      'This membership code is invalid. Ask the customer to show a fresh code.';

  @override
  String get m2MembershipBlocked =>
      'This membership or program is not available for loyalty operations.';

  @override
  String get m2ProgramMismatch =>
      'The program changed. Scan the membership again.';

  @override
  String get m2LocationBlocked =>
      'This operation is not authorized at the current location.';

  @override
  String get m2StampPolicyBlocked =>
      'The selected stamp amount is not permitted.';

  @override
  String get m2DailyLimit => 'The daily stamp allowance has been reached.';

  @override
  String get m2PurchaseRequired => 'Enter the required purchase amount.';

  @override
  String get m2CurrencyMismatch =>
      'Use the exact currency required by the program.';

  @override
  String get m2PurchaseThreshold =>
      'The purchase amount does not meet the required minimum.';

  @override
  String get m2FinalPending =>
      'Redeem the final reward before issuing more stamps.';

  @override
  String get m2RewardUnavailable => 'This reward is no longer available.';

  @override
  String get m2RewardExpired => 'This reward has expired.';

  @override
  String get m2RewardRedeemed => 'This reward was already redeemed.';

  @override
  String get m2ManagerApproval =>
      'An approved Manager flow is required. This app will not bypass it.';

  @override
  String get m2IdempotencyConflict =>
      'The original operation details do not match this command. Contact support.';

  @override
  String get m2OperationNotFound => 'The original command was not found.';

  @override
  String get m2OperationProcessing =>
      'The original operation is still processing.';

  @override
  String get m2OperationFailed =>
      'The original operation failed and no success was recorded.';

  @override
  String get m2BillingBlocked =>
      'Loyalty operations are unavailable for this organization.';

  @override
  String get m2RiskBlocked =>
      'Waflo blocked this operation for security review.';

  @override
  String get m2RateLimited =>
      'Too many requests. Wait briefly, then check again.';

  @override
  String get m2ContractError =>
      'Waflo returned an unsafe or incompatible response. Operations are disabled.';

  @override
  String get m2RecoveryExpired =>
      'This pending result needs Waflo support before another operation is attempted.';

  @override
  String get m2ResultUnknown =>
      'The server result is unknown. Do not repeat the operation; check its status.';
}
